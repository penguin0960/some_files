from django.db import models
from django.contrib.auth.models import User


class Genre(models.Model):
    name = models.CharField('Название', max_length=20)

    class Meta:
        verbose_name = 'Жанр'
        verbose_name_plural = 'Жанры'

    def __str__(self):
        return self.name


class Country(models.Model):
    name = models.CharField('Название', max_length=20)

    class Meta:
        verbose_name = 'Страна'
        verbose_name_plural = 'Страны'

    def __str__(self):
        return self.name


class Director(models.Model):
    first_name = models.CharField('Имя', max_length=20)
    last_name = models.CharField('Фамилия', max_length=20)

    class Meta:
        verbose_name = 'Режиссер'
        verbose_name_plural = 'Режиссеры'

    def __str__(self):
        return self.first_name + ' ' + self.last_name


class Film(models.Model):
    name = models.CharField('Название', max_length=50)
    director = models.ForeignKey(Director, verbose_name='Режиссер', null=True, on_delete=models.SET_NULL)
    country = models.ForeignKey(Country, verbose_name='Страна', null=True, on_delete=models.SET_NULL)
    genre = models.ForeignKey(Genre, verbose_name='Жанр', null=True, on_delete=models.SET_NULL)
    release_date = models.CharField('Год выхода', max_length=4)

    class Meta:
        verbose_name = 'Фильм'
        verbose_name_plural = 'Фильмы'

    def __str__(self):
        return self.name

    def get_rating(self):
        comments = Comment.objects.filter(film__exact=self)
        if comments:
            summa = 0
            for comment in comments:
                summa += comment.mark
            return round(summa/len(comments), 2)
        else:
            return 'Нет отзывов'


class Comment(models.Model):
    user = models.ForeignKey(User, verbose_name='Пользователь', on_delete=models.CASCADE)
    film = models.ForeignKey(Film, verbose_name='Фильм', on_delete=models.CASCADE)
    mark = models.IntegerField('Оценка')
    text = models.TextField('Текст')
    release_date = models.DateTimeField('Дата добавления')

    class Meta:
        verbose_name = 'Комментарий'
        verbose_name_plural = 'Комментарии'

    def __str__(self):
        return self.user + '->' + self.film + '->' + self.mark

from django.contrib import admin
from .models import Film, Genre, Country, Comment, Director

admin.site.register(Film)
admin.site.register(Genre)
admin.site.register(Director)
admin.site.register(Country)
admin.site.register(Comment)

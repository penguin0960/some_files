from django.shortcuts import get_object_or_404, render, redirect
from .models import Film, Comment
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.utils import timezone


def index(request):
    films = Film.objects.all()
    context = {
        'films': films,
    }
    return render(request, 'films/index.html', context)


def detail(request, id):
    if not request.user.is_authenticated:
        return redirect('index')
    film = get_object_or_404(Film, pk=id)
    if request.method == 'POST':
        mark = request.POST['mark']
        text = request.POST['text']

        if text and mark.isdigit():
            comment = Comment(user=request.user,
                              film=film,
                              mark=int(mark),
                              text=text,
                              release_date=timezone.now())
            comment.save()

    try:
        user_comment = Comment.objects.filter(film__exact=film).get(user=request.user)
    except:
        user_comment = None
    comments = Comment.objects.filter(film__exact=film).exclude(user__exact=request.user)
    context = {
        'film': film,
        'comments': comments,
        'user_comment': user_comment,
    }
    return render(request, 'films/detail.html', context)


def register(request):
    if request.method == 'POST':
        username = request.POST['username'].strip()
        first_name = request.POST['first_name'].strip()
        last_name = request.POST['last_name'].strip()
        password1 = request.POST['password1'].strip()
        password2 = request.POST['password2'].strip()
        mail = request.POST['mail'].strip()

        if username and first_name and last_name and password1 and password2 and mail and password2 == password1:
            user = User.objects.create_user(username, mail, password1,
                                            first_name=first_name,
                                            last_name=last_name, )
            user.save()
            login(request, user)
            return redirect('index')
        else:
            return render(request, 'registration/register.html', {
                'error': 'Получены некорректные данные'
            })

    return render(request, 'registration/register.html')


def rating(request):
    if not request.user.is_authenticated:
        return redirect('index')
    films = Film.objects.all()
    films_context = []
    for film in films:
        films_context.append({
            'film': film,
            'mark': film.get_rating(),
        })
    context = {
        'films': films_context,
    }
    return render(request, 'films/rating.html', context)
